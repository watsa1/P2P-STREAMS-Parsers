# -*- coding: utf-8 -*-

""" 
This plugin is 3rd party and not part of p2p-streams addon

Livefootballaol.com
"""
import sys,os
current_dir = os.path.dirname(os.path.realpath(__file__))
basename = os.path.basename(current_dir)
core_dir =  current_dir.replace(basename,'').replace('parsers','')
sys.path.append(core_dir)
from utils.webutils import *
from utils.pluginxbmc import *
from utils.directoryhandle import *

base_url = 'http://www.livefootballol.com/sopcast-channel-list.html'

def module_tree(name,url,iconimage,mode,parser,parserfunction):
	if not parserfunction: livefootballaol_main()
    
def livefootballaol_main():
	try:
		source = get_page_source(base_url)
	except: source="";xbmcgui.Dialog().ok(translate(40000),translate(40128))
	if source:
		match = re.compile('">(.+?)</s.+?td>\n<td>(.+?)</td>\n<td>(.+?)</td>').findall(source)
		for titulo,sopaddress,language in match:
			addDir("[B][COLOR orange][SopCast] [/COLOR]"+titulo.replace('<strong>','').replace('</a>','')+"[/B] ("+language.replace('<strong>','').replace('</strong>','')+ ')',sopaddress,2,os.path.join(current_dir,"icon.png"),len(match),False)
